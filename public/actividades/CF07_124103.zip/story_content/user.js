function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5qgOdRQB1XV":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

